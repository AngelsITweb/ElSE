bot_token = ''
owner = 
